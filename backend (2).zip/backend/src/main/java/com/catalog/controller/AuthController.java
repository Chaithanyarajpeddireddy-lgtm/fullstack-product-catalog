
package com.catalog.controller;

import com.catalog.model.User;
import com.catalog.repository.UserRepository;
import com.catalog.service.JwtUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
    	
    	
    	System.out.println("REGISTER HIT");

        if (userRepository.existsByUsername(user.getUsername())) {
            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(Map.of("error", "Username already exists"));
        }

        // Validate role
        if (user.getRole() == null ||
                (!user.getRole().equals("ROLE_ADMIN")
                        && !user.getRole().equals("ROLE_MANAGER")
                        && !user.getRole().equals("ROLE_CUSTOMER"))) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "error",
                            "Role must be ROLE_ADMIN, ROLE_MANAGER, or ROLE_CUSTOMER"
                    ));
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));

        User savedUser = userRepository.save(user);

        return ResponseEntity.ok(Map.of(
                "id", savedUser.getId(),
                "username", savedUser.getUsername(),
                "role", savedUser.getRole()
        ));
    }
    
    
    @GetMapping("/test")
    public String test() {
        System.out.println("TEST HIT");
        return "Auth Controller Working";
    }
    
    
    // ✅ Login endpoint (verify against PostgreSQL)
//   @PostMapping("/login")
//public ResponseEntity<?> login(@RequestBody User user) {
//
//    System.out.println("LOGIN HIT");
//
//    User dbUser = userRepository.findByUsername(user.getUsername())
//            .orElse(null);
//
//    if (dbUser == null) {
//        return ResponseEntity
//                .status(HttpStatus.NOT_FOUND)
//                .body(Map.of("error", "User not found"));
//    }
//
//    if (!passwordEncoder.matches(user.getPassword(), dbUser.getPassword())) {
//        return ResponseEntity
//                .status(HttpStatus.UNAUTHORIZED)
//                .body(Map.of("error", "Invalid credentials"));
//    }
//
//    String token = jwtUtil.generateToken(dbUser.getUsername());
//
//    return ResponseEntity.ok(Map.of(
//            "id", dbUser.getId(),
//            "token", token,
//            "username", dbUser.getUsername(),
//            "role", dbUser.getRole()
//    ));
//}
   
   
   
   @PostMapping("/login")
   public ResponseEntity<?> login(@RequestBody User user) {

       System.out.println("LOGIN HIT");

       User dbUser = userRepository.findByUsername(user.getUsername())
               .orElse(null);

       System.out.println("DB USER = " + dbUser);

       if (dbUser == null) {
           System.out.println("USER NOT FOUND");
           return ResponseEntity.status(HttpStatus.NOT_FOUND)
                   .body(Map.of("error", "User not found"));
       }

       System.out.println("INPUT PASSWORD = " + user.getPassword());
       System.out.println("DB HASH = " + dbUser.getPassword());

       boolean matches =
               passwordEncoder.matches(user.getPassword(),
                                       dbUser.getPassword());

       System.out.println("PASSWORD MATCH = " + matches);

       if (!matches) {
           return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                   .body(Map.of("error", "Invalid credentials"));
       }

       String token = jwtUtil.generateToken(dbUser.getUsername());

       System.out.println("TOKEN GENERATED");

       return ResponseEntity.ok(Map.of(
               "id", dbUser.getId(),
               "token", token,
               "username", dbUser.getUsername(),
               "role", dbUser.getRole()
       ));
   }
   
   
   
   
   
   
   
   
}

